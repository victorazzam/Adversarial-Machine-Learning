import glob
from pandas import read_csv, DataFrame
from sklearn.svm import SVC, LinearSVC
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from feature_extraction import feature_extraction

# Print each individual test
DEBUG = False

# Load prepared data set
df = read_csv('pdfdataset_n.csv')

# Choose appropriate fields
X = df.iloc[:, 0: 21]
y = df.iloc[:, 21]

# Split into training and testing
X_train, X_test, y_train, y_test = train_test_split(X.values, y.values, test_size=0.3)

# Various algorithms to try
algs = (
    ( 'Random Forest', RandomForestClassifier       ),
    ( 'Support Vector Machine', SVC                 ),
    ( 'Linear Support Vector', LinearSVC            ),
    ( 'Multilayer Perceptron', MLPClassifier        ),
    ( 'K-Nearest Neighbours', KNeighborsClassifier  )
)

# Answers for which PDFs are malicious
with open('solutions.txt') as f:
    solutions = {(a:=i.split())[0]:a[1] for i in f}

try:
    for name, method in algs:
        print('\n' + name + '\n' + '-'*len(name))
        model = method()
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        acs = round(accuracy_score(y_test, y_pred) * 100, 2)
        print(f'Training accuracy: {acs}%')
        if DEBUG:
            print('Y:malicious N:clean')
        results = {}
        correct = []
        for i in glob.iglob('**/*.pdf*', recursive=True):
            try:
                features = DataFrame(feature_extraction(i))
                result = model.predict(features)[0][0].upper()
                results[result] = results.get(result, 0) + 1
                correct.append(result == solutions[i.split('.')[0]])
                if DEBUG:
                    print(f'{result}: {i}')
            except Exception:
                print('Error:', i)
        if DEBUG:
            for k, v in results.items():
                print(f'{v} x {k}')
        accuracy = correct.count(True) / len(correct) * 100
        print(f'Final accuracy: {round(accuracy, 2)}%')
except KeyboardInterrupt:
    print()
